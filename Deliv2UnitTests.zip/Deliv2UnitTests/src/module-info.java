/**
 * 
 */
/**
 * 
 */
module TestProject {
	requires junit;
}